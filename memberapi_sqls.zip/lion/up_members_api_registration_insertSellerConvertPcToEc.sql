/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: ������Ǹ�ȸ����ȯ ��û���� �߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertSellerConvertPcToEc
(
      @cust_no              varchar(10)
    , @cust_type            char(2)
    , @login_id             varchar(10)
    , @cust_nm              varchar(50)
    , @corp_no              varchar(14)
    , @email                varchar(50)
    , @phone                varchar(20)
    , @hp                   varchar(20)
    , @zip_code             varchar(7) = ''
    , @address1             varchar(200) = ''
    , @address2             varchar(200)= ''
    , @jaehu_id             varchar(30) = 'N/A'
    , @master_nm            varchar(50) = ''
    , @mgr_nm               varchar(20) = ''
    , @isrcvmail            varchar(1)
    , @rcmd_id              varchar(10) = 'N/A'
    , @adjuster_nm          varchar(20) = ''
    , @adjuster_email       varchar(50) = ''
    , @adjuster_phone       varchar(20) = ''
    , @adjuster_hp          varchar(20) = ''
    , @fax                  varchar(20) = ''
    , @accountm_deposit_nm  varchar(50) = ''
    , @accountm_co_bank_cd  varchar(10) = ''
    , @accountm_co_acnt_cd  varchar(30) = ''
    , @helpdesk_phone       varchar(20) = ''
    , @tax_issue_yn         char(1) = 'N'
    , @nickname             varchar(20) = ''
    , @intro                varchar(500) = ''
    , @job_gubun1           varchar(50) = ''
    , @job_gubun2           varchar(50) = ''
    , @nation_code          char(2) = 'KR'
    , @taxkind              int = null
    , @ecomerce_no          varchar(20) = null
    , @exception_reason     varchar(1000) = null
    , @tel_no1              varchar(20)=''
    , @tel_no2              varchar(20)=''
    , @tel_no3              varchar(20)=''
    , @tel_no4              varchar(20)=''
    , @use_case1            varchar(20)=''
    , @use_case2            varchar(20)=''
    , @use_case3            varchar(20)=''
    , @use_case4            varchar(20)=''
    , @seller_etc_type      char(1) = null
    , @sttl_account_no      varchar(100) = ''
    , @seller_type          char(1) = 'E'
    , @ccust_cmpnm          varchar(50)=''
    , @remit_way            varchar(1) = 'B'
    , @ecomerce_report_yn   char(1) = null
    , @ecomerce_unreport_reason_cd    char(1) = null
    , @road_nm_front_addr   varchar(200) = ''
    , @road_nm_back_addr    varchar(200) = ''
    , @sellerdcagreeyn      char(1) = ''
    , @basic_domain         varchar(20) = ''
    , @co_reg_no            varchar(30)
)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

    declare @seq int
    select  @seq = isnull(MAX(seq), 0) + 1
    from    lion.dbo.seller_convert_pc_to_ec with(nolock)
    where   cust_no = @cust_no

    insert into dbo.seller_convert_pc_to_ec(
              cust_no
            , seq
            , cust_type
            , cust_type_chg_yn
            , login_id
            , info_na
            , corp_no
            , info_em
            , info_ht
            , info_cp
            , zip_code
            , info_ad1
            , info_ad2
            , jaehu_id
            , master_nm
            , mgr_nm
            , isrcvmail
            , rcmd_id
            , adjuster_nm
            , adjuster_info_em
            , adjuster_info_ht
            , adjuster_info_cp
            , commission_nego_yn
            , gsm_edu_yn
            , gsm_edu_date
            , fax
            , accountm_deposit_nm
            , accountm_co_bank_cd
            , helpdesk_phone
            , tax_issue_yn
            , nickname
            , intro
            , corp_reg_event
            , job_gubun1
            , job_gubun2
            , reg_address
            , minishop_cust_no
            , nation_code
            , taxkind
            , ecomerce_no
            , exception_reason
            , transc_cd
            , expose_helpdesk_telno_yn
            , tel_no1
            , tel_no2
            , tel_no3
            , tel_no4
            , use_case1
            , use_case2
            , use_case3
            , use_case4
            , seller_etc_type
            , check_exists_yn
            , sttl_account_no
            , seller_type
            , front_reg_id
            , ccust_cmpnm
            , pers_info_keep_yn
            , remit_way
            , ecomerce_report_yn
            , ecomerce_unreport_reason_cd
            , road_nm_front_addr
            , road_nm_back_addr
            , enc_1_pa
            , gbank_enc_1_pa
            , sellerdcagreeyn
            , proc_stat
            , reg_dt
            , reg_id
            , basic_domain
            , co_reg_no
    ) values (
              @cust_no
            , @seq
            , @cust_type
            , 'Y'
            , @login_id
            , @cust_nm
            , @corp_no
            , @email
            , @phone
            , @hp
            , @zip_code
            , @address1
            , @address2
            , @jaehu_id
            , @master_nm
            , @mgr_nm
            , @isrcvmail
            , @rcmd_id
            , @adjuster_nm
            , @adjuster_email
            , @adjuster_phone
            , @adjuster_hp
            , 'N'
            , 'N'
            , ''
            , @fax
            , @accountm_deposit_nm
            , @accountm_co_bank_cd
            , @helpdesk_phone
            , @tax_issue_yn
            , @nickname
            , @intro
            , 'N'
            , @job_gubun1
            , @job_gubun2
            , @address1 + ' '+ @address2
            , ''
            , @nation_code
            , @taxkind
            , @ecomerce_no
            , @exception_reason
            , '100000001'
            , 'Y'
            , @tel_no1
            , @tel_no2
            , @tel_no3
            , @tel_no4
            , @use_case1
            , @use_case2
            , @use_case3
            , @use_case4
            , @seller_etc_type
            , '0'
            , @sttl_account_no
            , @seller_type
            , 'G_FRONT'
            , @ccust_cmpnm
            , 'Y'
            , @remit_way
            , @ecomerce_report_yn
            , @ecomerce_unreport_reason_cd
            , @road_nm_front_addr
            , @road_nm_back_addr
            , hashbytes('sha1', 'password')
            , hashbytes('sha1', 'password')
            , @sellerdcagreeyn
            , 'SW'
            , @today
            , 'G_FRONT'
            , @basic_domain
            , @co_reg_no
        )

    set nocount off
end