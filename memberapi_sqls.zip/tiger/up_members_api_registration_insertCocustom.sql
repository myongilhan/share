/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: ��������߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertCocustom
(
      @cust_no                  varchar(10)
    , @ccust_cmpnm              varchar(50) = null
    , @corp_no                  varchar(20)
    , @dun_no                   varchar(20) = null
    , @ccust_cl                 varchar(4) = null
    , @mgr_dept                 varchar(20) = null
    , @mgr_nm                   varchar(20) = null
    , @capital                  money
    , @build_dt                 datetime = null
    , @upjong                   varchar(50) = null
    , @num_employee             int = 0
    , @sttl_month               smallint = 12
    , @major_prodt              varchar(100) = null
    , @co_site_url              varchar(100) = null
    , @uptae                    varchar(50) = null
    , @co_reg_no                varchar(30) = null
    , @zip_code                 char(7) = null
    , @top_mgr_confirm_dt       datetime = null
    , @view_cd                  tinyint = null
    , @address_no               int = null
    , @mgr_identification_no    varchar(32) = null
    , @seller_etc_type          char(1) = null
    , @oversea_corp_no          varchar(50) = null
    , @tin                      varchar(50) = null
    , @fax_no                   varchar(20) = null
    , @front_address            varchar(150) = null
    , @mgr_email                varchar(50) = null
    , @mgr_hp                   varchar(20) = null
    , @mgr_tel_no               varchar(20) = null
    , @rear_address             varchar(150) = null
    , @top_mgr                  varchar(50) = null
    , @road_nm_info_ad1         varchar(200) = null
    , @road_nm_info_ad2         varchar(200) = null
    , @biz_birth_dt             char(6) = null
    , @birth_dt_input_dt        smalldatetime = null

)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

    insert into dbo.cocustom(
          cust_no
        , ccust_cmpnm
        , corp_no
        , dun_no
        , ccust_cl
        , mgr_dept
        , mgr_nm
        , capital
        , build_dt
        , upjong
        , num_employee
        , sttl_month
        , major_prodt
        , co_site_url
        , uptae
        , co_reg_no
        , zip_code
        , top_mgr_confirm_dt
        , chg_dt
        , view_cd
        , address_no
        , mgr_identification_no
        , seller_etc_type
        , oversea_corp_no
        , tin
        , fax_no
        , front_address
        , mgr_email
        , mgr_hp
        , mgr_tel_no
        , rear_address
        , top_mgr
        , road_nm_info_ad1
        , road_nm_info_ad2
        , biz_birth_dt
        , birth_dt_input_dt
    ) values (
          @cust_no
        , @ccust_cmpnm
        , @corp_no
        , @dun_no
        , @ccust_cl
        , @mgr_dept
        , @mgr_nm
        , @capital
        , @build_dt
        , @upjong
        , @num_employee
        , @sttl_month
        , @major_prodt
        , @co_site_url
        , @uptae
        , @co_reg_no
        , @zip_code
        , @top_mgr_confirm_dt
        , @today
        , @view_cd
        , @address_no
        , @mgr_identification_no
        , @seller_etc_type
        , @oversea_corp_no
        , @tin
        , @fax_no
        , @front_address
        , @mgr_email
        , @mgr_hp
        , @mgr_tel_no
        , @rear_address
        , @top_mgr
        , @road_nm_info_ad1
        , @road_nm_info_ad2
        , @biz_birth_dt
        , @birth_dt_input_dt
    )

    set nocount off
end