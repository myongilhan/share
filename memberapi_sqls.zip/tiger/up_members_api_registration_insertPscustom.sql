/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: ��Ÿ ���� ���� �Է��ϱ�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertPscustom
(
      @cust_no           varchar(10)
    , @birth_cl          char(1) = null
    , @gender            char(1) = null
    , @birthday          varchar(8) = null
    , @married_yn        char(1) = null
    , @wedding_dt        varchar(8) = null
    , @job_cd            varchar(2) = null
    , @etc_job           varchar(100) = null
    , @hobby_cd          varchar(2) = null
    , @etc_hobby         varchar(20) = null
    , @interest_cd       varchar(20) = null
    , @etc_interest      varchar(20) = null
    , @enter_why         varchar(2) = null
    , @b2e_ref_id        varchar(10) = null
    , @b2e_ref_relation  varchar(2) = null
    , @b2e_bef_conm      varchar(50) = null
    , @b2e_latest_year   varchar(10) = null
    , @join_from         char(2) = 'KR'
    , @join_info_em      varchar(50) = null
)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

    insert into dbo.pscustom(
          cust_no
        , birth_cl
        , gender
        , birthday
        , married_yn
        , wedding_dt
        , job_cd
        , etc_job
        , hobby_cd
        , etc_hobby
        , interest_cd
        , etc_interest
        , enter_why
        , b2e_ref_id
        , b2e_ref_relation
        , b2e_bef_conm
        , b2e_latest_year
        , chg_dt
        , join_from
        , join_info_em
    ) values (
          @cust_no
        , @birth_cl
        , @gender
        , @birthday
        , @married_yn
        , @wedding_dt
        , @job_cd
        , @etc_job
        , @hobby_cd
        , @etc_hobby
        , @interest_cd
        , @etc_interest
        , @enter_why
        , @b2e_ref_id
        , @b2e_ref_relation
        , @b2e_bef_conm
        , @b2e_latest_year
        , @today
        , @join_from
        , @join_info_em
    )

    set nocount off
end