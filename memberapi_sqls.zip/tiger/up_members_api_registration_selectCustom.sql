/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: �������� ��ȸ
. ���ñ��:
. ����SP��:
. ���࿹��
    dbo.up_members_api_custom_select '112627632'
*****************************************************************************************************************
���泻��:
			��������				��������				������					��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_selectCustom
(
      @cust_no                   varchar(10)    
)
as
begin
    set nocount on

    select  cust_no
            , cust_nm
            , custreg_no
            , alias_nm
            , login_id
            , pass_question
            , rcmd_id
            , cust_type
            , zip_code
            , pass_answer
            , cust_gr
            , stat
            , sms_rcv_yn
            , ms_type
            , use_power
            , ms_id
            , ms_rcv_yn
            , e_rcv_yn
            , credit_point
            , reg_id
            , milage
            , reg_dt
            , chg_id
            , chg_dt
            , eft_dt
            , onoff
            , reserve
            , why
            , chip
            , finder_id
            , cust_character
            , donation_way
            , donation_alias
            , email_open_yn
            , rcmd_cust_no
            , bmo
            , b2e_iid
            , resting_yn
            , nation_code
            , foreigner_no
            , withdraw_dt
            , adult_use_yn
            , jaehu_cust_no
            , cash_receipt_yn
            , hp_agency
            , mb_rcv_yn
            , gbankloginuse
            , sys_chg_dt
            , birth_date
            , gender
            , corp_id_no
            , isforeign
            , address_no
            , identification_no
            , safe_login
            , reg_type
            , BUY_GRADE
            , address
            , E_MAIL
            , HP_NO
            , mgr
            , tel_no
            , BACK_ADDRESS
            , CB_TEL_NO
            , FRONT_ADDRESS
            , ROAD_NM_INFO_AD1
            , ROAD_NM_INFO_AD2
    from    dbo.custom(nolock)
    where   cust_no = @cust_no

    set nocount off
end