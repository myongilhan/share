/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: ���ǿ����߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertCustomAgreement
(
      @cust_no                          varchar(10)
    , @login_id                         varchar(10)
    , @cust_type                        varchar(2)
    , @buyer_agr_yn                     char(1) = 'N'
    , @seller_agr_yn                    char(1) = 'N'
    , @tpayment_agr_yn                  char(1) = 'N'
    , @efinance_agr_yn                  char(1) = 'N'
    , @sel_privacy_agr_yn               char(1) = null
    , @personal_info_supply_agr_yn      char(1) = null
    , @personal_info_treat_agr_yn       char(1) = null
    , @personal_info_treat_agr_where    char(1) = 'R'
    , @identification_info_use_agr_yn   char(1) = null
    , @foreigner_no_use_agree_yn        char(1) = null    
    , @cust_nm                          varchar(50) = null
)
as
begin
    set nocount on

    declare @today datetime
    set @today = getdate()

    declare   @personal_info_supply_agr_dt      datetime
            , @personal_info_treat_agr_dt       datetime
            , @identification_info_use_agr_id   varchar(10)
            , @identification_info_use_agr_dt   datetime    
            , @foreigner_no_use_agree_id        varchar(10)
            , @foreigner_no_use_agree_dt        datetime
    
    if @personal_info_supply_agr_yn in ('Y', 'N')
    begin
        set @personal_info_supply_agr_dt = @today
    end

    if @personal_info_treat_agr_yn in ('Y', 'N')
    begin
        set @personal_info_treat_agr_dt = @today
    end

    if @identification_info_use_agr_yn in ('Y', 'N')
    begin
        set @identification_info_use_agr_id = @login_id
        set @identification_info_use_agr_dt = @today
    end

    if @foreigner_no_use_agree_yn in ('Y', 'N')
    begin
        set @foreigner_no_use_agree_id = @login_id
        set @foreigner_no_use_agree_dt = @today
    end    

    insert into dbo.custom_agreement(
          cust_no
        , login_id
        , cust_type
        , buyer_agr_yn
        , seller_agr_yn
        , tpayment_agr_yn
        , efinance_agr_yn
        , chg_dt
        , sel_privacy_agr_yn
        , personal_info_supply_agr_yn
        , personal_info_treat_agr_yn
        , personal_info_supply_agr_dt
        , personal_info_treat_agr_dt
        , personal_info_treat_agr_where
        , identification_info_use_agr_yn
        , identification_info_use_agr_id
        , identification_info_use_agr_dt
        , foreigner_no_use_agree_yn
        , foreigner_no_use_agree_id
        , foreigner_no_use_agree_dt
        , cust_nm
    ) values (
          @cust_no
        , @login_id
        , @cust_type
        , @buyer_agr_yn
        , @seller_agr_yn
        , @tpayment_agr_yn
        , @efinance_agr_yn
        , @today
        , @sel_privacy_agr_yn
        , @personal_info_supply_agr_yn
        , @personal_info_treat_agr_yn
        , @personal_info_supply_agr_dt
        , @personal_info_treat_agr_dt
        , @personal_info_treat_agr_where
        , @identification_info_use_agr_yn
        , @identification_info_use_agr_id
        , @identification_info_use_agr_dt
        , @foreigner_no_use_agree_yn
        , @foreigner_no_use_agree_id
        , @foreigner_no_use_agree_dt
        , @cust_nm
    )

    set nocount off
end