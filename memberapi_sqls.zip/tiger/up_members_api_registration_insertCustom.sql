/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: �������� �߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertCustom
(
      @cust_no                   varchar(10)
    , @cust_nm                   varchar(50)
    , @custreg_no                varchar(10)
    , @alias_nm                  varchar(50)
    , @login_id                  varchar(10)
    , @pass_question             varchar(40) = null
    , @rcmd_id                   varchar(10) = null
    , @cust_type                 varchar(2)
    , @zip_code                  varchar(8) = null
    , @pass_answer               varchar(20) = null
    , @cust_gr                   varchar(2) = 'C1'
    , @stat                      varchar(2)
    , @sms_rcv_yn                char(1) = null
    , @ms_type                   varchar(4) = null
    , @use_power                 varchar(2) = 'PA'
    , @ms_id                     varchar(10) = null
    , @ms_rcv_yn                 char(1) = 'N'
    , @e_rcv_yn                  char(1) = null
    , @credit_point              int
    , @reg_id                    varchar(10) = 'G_FRONT'
    , @milage                    int = 0
    , @onoff                     char(1) = 'Y'
    , @reserve                   varchar(10) = null
    , @why                       varchar(20) = null
    , @chip                      int = 0
    , @finder_id                 varchar(10) = null
    , @cust_character            varchar(1000) = null
    , @donation_way              varchar(1) = 'N'
    , @donation_alias            varchar(50) = null
    , @email_open_yn             varchar(1) = 'N'
    , @rcmd_cust_no              varchar(10) = null
    , @bmo                       varchar(1) = 'Y'
    , @b2e_iid                   int = 0
    , @resting_yn                char(1) = 'N'
    , @nation_code               char(2) = 'KR'
    , @foreigner_no              char(19) = null
    , @adult_use_yn              char(1) = 'N'
    , @cash_receipt_yn           char(1) = 'N'
    , @hp_agency                 char(1) = ''
    , @mb_rcv_yn                 char(1) = 'N'
    , @gbankloginuse             bit = null
    , @birth_date                char(6) = null
    , @gender                    char(1) = null
    , @corp_id_no                varchar(20) = null
    , @isforeign                 bit = 0
    , @address_no                int = null
    , @identification_no         varchar(32) = null
    , @safe_login                tinyint = 4
    , @reg_type                  char(1) = 'S'
    , @BUY_GRADE                 tinyint = 50
    , @address                   varchar(200) = null
    , @E_MAIL                    varchar(50) = null
    , @HP_NO                     varchar(20) = null
    , @mgr                       varchar(20) = null
    , @tel_no                    varchar(20) = null
    , @BACK_ADDRESS              varchar(200) = null
    , @CB_TEL_NO                 varchar(20) = null
    , @FRONT_ADDRESS             varchar(200) = null
    , @ROAD_NM_INFO_AD1          varchar(200) = null
    , @ROAD_NM_INFO_AD2          varchar(200) = null
)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

    insert into dbo.custom(
        cust_no
        , cust_nm
        , custreg_no
        , alias_nm
        , login_id
        , pass_question
        , rcmd_id
        , cust_type
        , zip_code
        , pass_answer
        , cust_gr
        , stat
        , sms_rcv_yn
        , ms_type
        , use_power
        , ms_id
        , ms_rcv_yn
        , e_rcv_yn
        , credit_point
        , reg_id
        , milage
        , reg_dt
        , chg_dt
        , eft_dt
        , onoff
        , reserve
        , why
        , chip
        , finder_id
        , cust_character
        , donation_way
        , donation_alias
        , email_open_yn
        , rcmd_cust_no
        , bmo
        , b2e_iid
        , resting_yn
        , nation_code
        , foreigner_no
        , adult_use_yn
        , cash_receipt_yn
        , hp_agency
        , mb_rcv_yn
        , gbankloginuse
        , sys_chg_dt
        , birth_date
        , gender
        , corp_id_no
        , isforeign
        , address_no
        , identification_no
        , safe_login
        , reg_type
        , BUY_GRADE
        , address
        , E_MAIL
        , HP_NO
        , mgr
        , tel_no
        , BACK_ADDRESS
        , CB_TEL_NO
        , FRONT_ADDRESS
        , ROAD_NM_INFO_AD1
        , ROAD_NM_INFO_AD2)
    values(
        @cust_no
        , @cust_nm
        , @custreg_no
        , @alias_nm
        , @login_id
        , @pass_question
        , @rcmd_id
        , @cust_type
        , @zip_code
        , @pass_answer
        , @cust_gr
        , @stat
        , @sms_rcv_yn
        , @ms_type
        , @use_power
        , @ms_id
        , @ms_rcv_yn
        , @e_rcv_yn
        , @credit_point
        , @reg_id
        , @milage
        , @today
        , @today
        , @today
        , @onoff
        , @reserve
        , @why
        , @chip
        , @finder_id
        , @cust_character
        , @donation_way
        , @donation_alias
        , @email_open_yn
        , @rcmd_cust_no
        , @bmo
        , @b2e_iid
        , @resting_yn
        , @nation_code
        , @foreigner_no
        , @adult_use_yn
        , @cash_receipt_yn
        , @hp_agency
        , @mb_rcv_yn
        , @gbankloginuse
        , @today
        , @birth_date
        , @gender
        , @corp_id_no
        , @isforeign
        , @address_no
        , @identification_no
        , @safe_login
        , @reg_type
        , @BUY_GRADE
        , @address
        , @E_MAIL
        , @HP_NO
        , @mgr
        , @tel_no
        , @BACK_ADDRESS
        , @CB_TEL_NO
        , @FRONT_ADDRESS
        , @ROAD_NM_INFO_AD1
        , @ROAD_NM_INFO_AD2)

    set nocount off
end