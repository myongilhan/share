/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: ci/di ���� �߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertCustomIPinInfo
(
      @d_i                      varchar(64)
    , @c_i                      varchar(88)
    , @cust_no                  varchar(10) = null
    , @name                     varchar(50)
    , @birthday                 varchar(8)
    , @gender                   bit
    , @foreigner                bit
    , @auth_date                varchar(12)
    , @client_ip                varchar(15) = null
    , @virtual_id_num           varchar(14) = null
    , @age_group                int = null
    , @verification_string      varchar(100) = null
    , @reg_id                   varchar(10) ='system'
    , @reg_where                char(1) = 'F'
    , @stat                     char(2) = 'S1'
    , @enc_data                 varchar(250) = null
    , @cp_req_data              varchar(50) = null
    , @cp_name                  varchar(10) = 'KISINFO'
    , @PERS_INFO_KEEP_YN        char(1) = null
    , @JOIN_PERS_INFO_KEEP_YN   char(1) = null
    , @ORDER_PERS_INFO_KEEP_YN  char(1) = null
    , @ORDER_PERS_INFO_KEEP_DT  datetime = null
)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

    insert into dbo.custom_i_pin_info(        
          d_i
        , c_i
        , cust_no
        , name
        , birthday
        , gender
        , foreigner
        , auth_date
        , client_ip
        , virtual_id_num
        , age_group
        , verification_string
        , reg_dt
        , reg_id
        , chg_dt
        , chg_id
        , reg_where
        , stat
        , enc_data
        , cp_req_data
        , cp_name
        , PERS_INFO_KEEP_YN
        , JOIN_PERS_INFO_KEEP_YN
        , ORDER_PERS_INFO_KEEP_YN
        , ORDER_PERS_INFO_KEEP_DT
    ) values(
         @d_i
        , @c_i
        , @cust_no
        , @name
        , @birthday
        , @gender
        , @foreigner
        , @auth_date
        , @client_ip
        , @virtual_id_num
        , @age_group
        , @verification_string
        , @today
        , @reg_id
        , @today
        , @reg_id
        , @reg_where
        , @stat
        , @enc_data
        , @cp_req_data
        , @cp_name
        , @PERS_INFO_KEEP_YN
        , @JOIN_PERS_INFO_KEEP_YN
        , @ORDER_PERS_INFO_KEEP_YN
        , @ORDER_PERS_INFO_KEEP_DT)
        
    set nocount off        
end