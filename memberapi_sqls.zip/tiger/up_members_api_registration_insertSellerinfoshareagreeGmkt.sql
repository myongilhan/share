/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: �Ǹ��� ���� ���� ���Ǹ� ����
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertSellerInfoShareAgreeGmkt
(
      @cust_no              varchar(10)
    , @identity_value       varchar(20)
    , @identity_type        char(1) = 'B'
    , @agreement_id         varchar(20)
    , @agreement_yn         char(1)
    , @agreement_method     char(1) = 'W'
    , @operator_id          varchar(20)
    , @operator_name        varchar(25)
)    
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @exists_count int
    

    if not exists ( select  1     
                    from    dbo.sellerinfoshareagree_gmkt with(nolock) 
                    where   identity_value = @identity_value)
                    
    begin
        insert into dbo.sellerinfoshareagree_gmkt(
              cust_no
            , identity_value
            , identity_type
            , agreement_id
            , agreement_yn
            , agreement_method
            , agreement_dt
            , reg_dt
            , reg_id
            , reg_name
            , chg_dt
            , chg_id
            , chg_name
        ) values (
              @cust_no
            , @identity_value
            , @identity_type
            , @agreement_id
            , @agreement_yn
            , @agreement_method
            , getdate()
            , getdate()
            , @operator_id
            , @operator_name
            , getdate()
            , @operator_id
            , @operator_name
        )
    end

    set nocount off    
end
