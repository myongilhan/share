/*****************************************************************************************************************
. �� �� ��: �Ѹ���
. �� �� ��: 2014-08-14
. ��������: members��
. ��ɱ���: API
. ��ɼ���: �Ǹ�������  �߰�
. ���ñ��:
. ����SP��:
. ���࿹��
*****************************************************************************************************************
���泻��:
��������    ��������    ������  ��������
=================================================================================================================
*****************************************************************************************************************/
create proc dbo.up_members_api_registration_insertDealerSettleTbl
(
      @cust_no                     varchar(10)
    , @seller_type                 char(1)
    , @settle_flag                 varchar(2)
    , @delev_type                  char(1)
    , @delev_method                char(1)
    , @transc_cd                   varchar(10)
    , @who_fee                     varchar(2)
    , @how_fee                     varchar(2)
    , @trust_confirm               varchar(1)
    , @settle_stat                 varchar(2)
    , @why_stop                    varchar(100)
    , @settle_uom                  int
    , @cl_uom_dt                   varchar(20)
    , @cl_uom                      varchar(20)
    , @reg_id                      varchar(10)
    , @chg_id                      varchar(10)
    , @onoff                       char(1)
    , @gd_reg_auth                 char(1)
    , @fr_reg_auth                 char(1)
    , @contract_doc_no             varchar(10)
    , @contract_confirm_yn         varchar(1)
    , @contract_confirm_id         varchar(10)
    , @certificate_confirm_yn      varchar(1)
    , @certificate_confirm_id      varchar(10)
    , @bankbook_confirm_yn         varchar(1)
    , @bankbook_confirm_id         varchar(50)
    , @gsm_use                     char(1)
    , @main_tb_cd                  varchar(10)
    , @match_yn                    char(1)
    , @estimate_yn                 char(1)
    , @gd_monopoly                 char(1)
    , @delev_auto                  char(1)
    , @agreement_yn                char(1)
    , @commission_nego             char(1)
    , @commission_nego_apply       char(1)
    , @gsm_edu_app_dt              char(8)
    , @gsm_edu_finish              char(1)
    , @partner_dealer              char(1)
    , @expose_nknm                 char(1)
    , @nickname                    varchar(20)
    , @dealer_intro                varchar(200)
    , @dealershop_use              char(1)
    , @dzno                        char(6)
    , @zerom_priceyn               char(1)
    , @tax_issue_yn                char(1)
    , @transcmpl_auto              char(1)
    , @img_nm1                     varchar(100)
    , @img_url1                    varchar(200)
    , @img_nm2                     varchar(100)
    , @img_url2                    varchar(200)
    , @img_nm3                     varchar(100)
    , @img_url3                    varchar(200)
    , @img_nm4                     varchar(100)
    , @img_url4                    varchar(200)
    , @img_nm5                     varchar(100)
    , @img_url5                    varchar(200)
    , @trans_fee_gubun             char(2)
    , @trans_fee                   int
    , @rx_zipcode                  char(7)
    , @minishop_priority           int
    , @dayofweek                   tinyint
    , @cash_issue_yn               char(1)
    , @jahue_yn                    bit
    , @settle_uom_hist             int
    , @taxkind                     bit
    , @ecomerce_no                 varchar(50)
    , @exception_reason            varchar(1000)
    , @overseatransportyn          bit
    , @rsv_svc_use_yn              bit
    , @rsv_svc_cmsn_rate           numeric(5)
    , @print_nm_type               tinyint
    , @print_paper_type            tinyint
    , @return_tb_cd                varchar(10)
    , @return_cd                   varchar(10)
    , @security_access_gubun       char(1)
    , @handphone_access_day        tinyint
    , @contr_cnt_1m                int
    , @oversea_transc_use_yn       varchar(1)
    , @oversea_transc_cd           varchar(10)
    , @oversea_trans_fee_sc        smallmoney
    , @oversea_trans_fee_tb        smallmoney
    , @oversea_trans_fee_sc_type   varchar(2)
    , @oversea_trans_fee_sc_id     varchar(10)
    , @brand_minishop_yn           char(1)
    , @delev_mail_rcv_yn           char(1)
    , @vod_agree_yn                char(1)
    , @seller_sub_type             char(1)
    , @print_gdnm_type             tinyint
    , @seller_union_info_disp      char(1)
    , @subnickname                 varchar(20)
    , @auto_refund_time            int
    , @visit_delivery_yn           char(1)
    , @output_stat                 tinyint
    , @quick_delivery_yn           char(1)
    , @quick_transc_cd             varchar(10)
    , @auto_tax_yn                 char(1)
    , @quick_enable_stime          varchar(5)
    , @quick_enable_etime          varchar(5)
    , @tax_issue_time              char(1)
    , @delay_deliv_yn              char(1)
    , @delay_deliv_dt              tinyint
    , @address_no                  int
    , @seller_sttl_no              varchar(6)
    , @entry_agreement_yn          varchar(1)
    , @dangol_mail_yn              char(1)
    , @dangol_mail_reason          varchar(100)
    , @helpdesk_sdt                varchar(8)
    , @helpdesk_edt                varchar(8)
    , @seller_multi_delivery_yn    char(1)
    , @auto_buy_decision_type      tinyint
    , @sttl_pre_dt_chg_yn          char(1)
    , @remit_way                   char(1)
    , @ecomerce_report_yn          char(1)
    , @ecomerce_unreport_reason_cd char(1)
    , @refund_way                  char(1)
    , @sell_account_chg_limit_yn   char(1)
    , @expose_helpdesk_telno_yn    char(1)
    , @helpdesk_tel_no             varchar(20)
    , @hotline_telno               varchar(20)
    , @sttl_mgr_email              varchar(50)
    , @sttl_mgr_hp                 varchar(20)
    , @sttl_mgr_nm                 varchar(20)
    , @sttl_mgr_tel                varchar(20)
    , @delev_num                   varchar(50)
    , @rx_back_address             varchar(100)
    , @rx_front_address            varchar(100)
    , @early_delivery_cmpl_yn      char(1)
    , @early_sttl_yn               char(1)
)
as
begin
    set nocount on
    set transaction isolation level read uncommitted

    declare @today datetime
    set @today = getdate()

  
    insert into dbo.dealersettletbl(
          cust_no
        , seller_type
        , settle_flag
        , delev_type
        , delev_method
        , transc_cd
        , who_fee
        , how_fee
        , trust_confirm
        , settle_stat
        , why_stop
        , settle_uom
        , cl_uom_dt
        , cl_uom
        , st_open_dt
        , reg_id
        , reg_dt
        , chg_id
        , chg_dt
        , onoff
        , gd_reg_auth
        , fr_reg_auth
        , contract_doc_no
        , contract_confirm_yn
        , contract_confirm_id
        , certificate_confirm_yn
        , certificate_confirm_id
        , bankbook_confirm_yn
        , bankbook_confirm_id
        , gsm_use
        , main_tb_cd
        , match_yn
        , estimate_yn
        , gd_monopoly
        , delev_auto
        , agreement_yn
        , commission_nego
        , commission_nego_apply
        , gsm_edu_app_dt
        , gsm_edu_finish
        , partner_dealer
        , expose_nknm
        , nickname
        , dealer_intro
        , dealershop_use
        , dzno
        , zerom_priceyn
        , tax_issue_yn
        , transcmpl_auto
        , img_nm1
        , img_url1
        , img_nm2
        , img_url2
        , img_nm3
        , img_url3
        , trans_fee_gubun
        , trans_fee
        , rx_zipcode
        , minishop_priority
        , dayofweek
        , cash_issue_yn
        , jahue_yn
        , settle_uom_hist
        , taxkind
        , ecomerce_no
        , exception_reason
        , overseatransportyn
        , rsv_svc_use_yn
        , rsv_svc_cmsn_rate
        , print_nm_type
        , print_paper_type
        , return_tb_cd
        , return_cd
        , security_access_gubun
        , handphone_access_day
        , contr_cnt_1m
        , oversea_transc_use_yn
        , oversea_transc_cd
        , oversea_trans_fee_sc
        , oversea_trans_fee_tb
        , oversea_trans_fee_sc_type
        , oversea_trans_fee_sc_id
        , oversea_trans_fee_sc_dt
        , oversea_transc_use_reg_dt
        , brand_minishop_yn
        , img_nm4
        , img_url4
        , img_nm5
        , img_url5
        , delev_mail_rcv_yn
        , vod_agree_yn
        , seller_sub_type
        , print_gdnm_type
        , seller_union_info_disp
        , subnickname
        , auto_refund_time
        , visit_delivery_yn
        , output_stat
        , quick_delivery_yn
        , quick_transc_cd
        , auto_tax_yn
        , quick_enable_stime
        , quick_enable_etime
        , tax_issue_time
        , delay_deliv_yn
        , delay_deliv_dt
        , address_no
        , seller_sttl_no
        , entry_agreement_yn
        , dangol_mail_yn
        , dangol_mail_reason
        , helpdesk_sdt
        , helpdesk_edt
        , seller_multi_delivery_yn
        , auto_buy_decision_type
        , sttl_pre_dt_chg_yn
        , remit_way
        , ecomerce_report_yn
        , ecomerce_unreport_reason_cd
        , refund_way
        , sell_account_chg_limit_yn
        , expose_helpdesk_telno_yn
        , helpdesk_tel_no
        , hotline_telno
        , sttl_mgr_email
        , sttl_mgr_hp
        , sttl_mgr_nm
        , sttl_mgr_tel
        , delev_num
        , rx_back_address
        , rx_front_address
        , early_delivery_cmpl_yn
        , early_sttl_yn
    ) values (
          @cust_no
        , @seller_type
        , @settle_flag
        , @delev_type
        , @delev_method
        , @transc_cd
        , @who_fee
        , @how_fee
        , @trust_confirm
        , @settle_stat
        , @why_stop
        , @settle_uom
        , @cl_uom_dt
        , @cl_uom
        , @today
        , @reg_id
        , @today
        , @chg_id
        , convert(datetime, '1900-01-01')
        , @onoff
        , @gd_reg_auth
        , @fr_reg_auth
        , @contract_doc_no
        , @contract_confirm_yn
        , @contract_confirm_id
        , @certificate_confirm_yn
        , @certificate_confirm_id
        , @bankbook_confirm_yn
        , @bankbook_confirm_id
        , @gsm_use
        , @main_tb_cd
        , @match_yn
        , @estimate_yn
        , @gd_monopoly
        , @delev_auto
        , @agreement_yn
        , @commission_nego
        , @commission_nego_apply
        , @gsm_edu_app_dt
        , @gsm_edu_finish
        , @partner_dealer
        , @expose_nknm
        , @nickname
        , @dealer_intro
        , @dealershop_use
        , @dzno
        , @zerom_priceyn
        , @tax_issue_yn
        , @transcmpl_auto
        , @img_nm1
        , @img_url1
        , @img_nm2
        , @img_url2
        , @img_nm3
        , @img_url3
        , @trans_fee_gubun
        , @trans_fee
        , @rx_zipcode
        , @minishop_priority
        , @dayofweek
        , @cash_issue_yn
        , @jahue_yn
        , @settle_uom_hist
        , @taxkind
        , @ecomerce_no
        , @exception_reason
        , @overseatransportyn
        , @rsv_svc_use_yn
        , @rsv_svc_cmsn_rate
        , @print_nm_type
        , @print_paper_type
        , @return_tb_cd
        , @return_cd
        , @security_access_gubun
        , @handphone_access_day
        , @contr_cnt_1m
        , @oversea_transc_use_yn
        , @oversea_transc_cd
        , @oversea_trans_fee_sc
        , @oversea_trans_fee_tb
        , @oversea_trans_fee_sc_type
        , @oversea_trans_fee_sc_id
        , @today
        , @today
        , @brand_minishop_yn
        , @img_nm4
        , @img_url4
        , @img_nm5
        , @img_url5
        , @delev_mail_rcv_yn
        , @vod_agree_yn
        , @seller_sub_type
        , @print_gdnm_type
        , @seller_union_info_disp
        , @subnickname
        , @auto_refund_time
        , @visit_delivery_yn
        , @output_stat
        , @quick_delivery_yn
        , @quick_transc_cd
        , @auto_tax_yn
        , @quick_enable_stime
        , @quick_enable_etime
        , @tax_issue_time
        , @delay_deliv_yn
        , @delay_deliv_dt
        , @address_no
        , @seller_sttl_no
        , @entry_agreement_yn
        , @dangol_mail_yn
        , @dangol_mail_reason
        , @helpdesk_sdt
        , @helpdesk_edt
        , @seller_multi_delivery_yn
        , @auto_buy_decision_type
        , @sttl_pre_dt_chg_yn
        , @remit_way
        , @ecomerce_report_yn
        , @ecomerce_unreport_reason_cd
        , @refund_way
        , @sell_account_chg_limit_yn
        , @expose_helpdesk_telno_yn
        , @helpdesk_tel_no
        , @hotline_telno
        , @sttl_mgr_email
        , @sttl_mgr_hp
        , @sttl_mgr_nm
        , @sttl_mgr_tel
        , @delev_num
        , @rx_back_address
        , @rx_front_address
        , @early_delivery_cmpl_yn
        , @early_sttl_yn
    )

    set nocount off
end